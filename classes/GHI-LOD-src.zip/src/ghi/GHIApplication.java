package ghi;


import java.io.File;
import org.restlet.Component;
import org.restlet.Restlet;
import org.restlet.routing.Router;
import org.restlet.data.Protocol;
import org.restlet.routing.Variable;


/**
 * The main Web application.
 * 
 */
public class GHIApplication extends org.restlet.Application 
  {
  private ConnectorToOntology connector; // this is a connector to ontology to retrieve data
  private LODReporter reporter; // this is a writer to xml or other format

  public GHIApplication() 
    {
	System.out.println("GHIApplication");  

	// connect to ontology to retrieve data
    
	connector = new ConnectorToOntology();
    reporter = new LODReporter(connector);
  
  
   }

    @Override
  public Restlet createInboundRoot() 
    {
    Router router = new Router(getContext());
//    Route defaultRoute = router.attachDefault(NeighborsResource.class);

    
      // neighbors 
     
//    router.attach("/", OntologyResource.class);
//    router.attach("/resource/", OntologyOverviewResource.class);
//    router.attach("/resource", OntologyOverviewResource.class);

 //   router.attach("/resource/{name}", HTMLResource.class);
 //   router.attach("/data/{name}", RDFResource.class);
    router.attach("/ghi/resource/{name}", HTMLResource.class);
    router.attach("/ghi/page/{name}", HTMLResource.class);
    router.attach("/ghi/resource/", OverviewPageResource.class);
    router.attach("/ghi/resource", OverviewPageResource.class);
 
    router.attach("/ghi/data/{name}", RDFResource.class);
    router.attach("/ghi/", OverviewPageResource.class);
    router.attach("/ghi", OverviewPageResource.class);

    router.attach("/ghi/en", OverviewPageResource.class);
    router.attach("/ghi/EN", OverviewPageResource.class);
    router.attach("/ghi/ES", OverviewPageESResource.class);
    router.attach("/ghi/es", OverviewPageESResource.class);
    router.attach("/ghi/FR", OverviewPageFRResource.class);
    router.attach("/ghi/fr", OverviewPageFRResource.class);

    
    // Add a route for user resources

    return router;
    }
  public ConnectorToOntology getOntology()
    {
    return this.connector;
    }
  
  public LODReporter getReporter()
    {
    return this.reporter;
    }

  }
